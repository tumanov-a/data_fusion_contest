
import pandas as pd
import numpy as np
import re
import pymorphy2
import spacy
import pickle
from spacy.matcher import PhraseMatcher
from spacy.lang.ru import Russian

def preprocess(text):
  replace_sign = [',', '.', '\"', '`', '/', '\\', ')', '(', '- ', ' -']
  for sign in replace_sign:
    text = text.replace(sign, ' ')
  text = text.replace('  ', ' ')
  return text.strip().lower()

def get_predictions(test):

  y_pred = []
  for item_name, brand in test.values:
    doc = nlp(item_name)
    all_spans = []
    for match_id, start, end in matcher(doc):
      span = doc[start:end]
      all_spans.append(span)
    if all_spans:
      most_longset_span = sorted(all_spans, key=lambda x: len(x), reverse=True)[0]
      y_pred.append(str(most_longset_span))
    else:
      y_pred.append('not found')
  return y_pred

nlp = pickle.load(open('nlp', 'rb'))
matcher = pickle.load(open('matcher', 'rb'))

test = pd.read_parquet('data/task2_test_for_user.parquet')
test['item_name'] = test['item_name'].apply(lambda x: preprocess(x))
test['brands'] = np.zeros_like(test['item_name'])

predicted_brand = get_predictions(test[['item_name', 'brands']])
test['pred'] = predicted_brand
test[['id', 'pred']].to_csv('answers.csv', index=None)